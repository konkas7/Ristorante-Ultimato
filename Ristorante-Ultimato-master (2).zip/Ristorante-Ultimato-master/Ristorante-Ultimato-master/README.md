# CrudRistorante-master

Lavoro fatto da Vita Thomas; Crud in grado di gestire le funzioni necessare di un programma per un ristorante, sia dalla parte del proprietario che da quella del cliente
