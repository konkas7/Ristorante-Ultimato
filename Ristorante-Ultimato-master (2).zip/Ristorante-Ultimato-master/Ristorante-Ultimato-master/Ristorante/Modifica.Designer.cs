﻿namespace Ristorante
{
    partial class Modifica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.namebox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.searchbutton = new System.Windows.Forms.Button();
            this.pricebox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.fourthbox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.thirdbox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.secondbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.firstbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.savebutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(168, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 69);
            this.label1.TabIndex = 1;
            this.label1.Text = "Modifica";
            // 
            // namebox
            // 
            this.namebox.Location = new System.Drawing.Point(63, 134);
            this.namebox.Margin = new System.Windows.Forms.Padding(4);
            this.namebox.Name = "namebox";
            this.namebox.Size = new System.Drawing.Size(195, 22);
            this.namebox.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(57, 101);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 29);
            this.label2.TabIndex = 8;
            this.label2.Text = "Nome *";
            // 
            // searchbutton
            // 
            this.searchbutton.BackColor = System.Drawing.Color.White;
            this.searchbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchbutton.Location = new System.Drawing.Point(355, 124);
            this.searchbutton.Margin = new System.Windows.Forms.Padding(4);
            this.searchbutton.Name = "searchbutton";
            this.searchbutton.Size = new System.Drawing.Size(144, 41);
            this.searchbutton.TabIndex = 19;
            this.searchbutton.Text = "Cerca";
            this.searchbutton.UseVisualStyleBackColor = false;
            this.searchbutton.Click += new System.EventHandler(this.searchbutton_Click);
            // 
            // pricebox
            // 
            this.pricebox.Location = new System.Drawing.Point(63, 250);
            this.pricebox.Margin = new System.Windows.Forms.Padding(4);
            this.pricebox.Name = "pricebox";
            this.pricebox.Size = new System.Drawing.Size(195, 22);
            this.pricebox.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(57, 217);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 29);
            this.label3.TabIndex = 20;
            this.label3.Text = "Prezzo";
            // 
            // fourthbox
            // 
            this.fourthbox.Location = new System.Drawing.Point(63, 418);
            this.fourthbox.Margin = new System.Windows.Forms.Padding(4);
            this.fourthbox.Name = "fourthbox";
            this.fourthbox.Size = new System.Drawing.Size(195, 22);
            this.fourthbox.TabIndex = 29;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(57, 385);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(154, 29);
            this.label7.TabIndex = 28;
            this.label7.Text = "4 ingrediente";
            // 
            // thirdbox
            // 
            this.thirdbox.Location = new System.Drawing.Point(327, 334);
            this.thirdbox.Margin = new System.Windows.Forms.Padding(4);
            this.thirdbox.Name = "thirdbox";
            this.thirdbox.Size = new System.Drawing.Size(195, 22);
            this.thirdbox.TabIndex = 27;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(321, 300);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 29);
            this.label6.TabIndex = 26;
            this.label6.Text = "3 ingrediente";
            // 
            // secondbox
            // 
            this.secondbox.Location = new System.Drawing.Point(63, 334);
            this.secondbox.Margin = new System.Windows.Forms.Padding(4);
            this.secondbox.Name = "secondbox";
            this.secondbox.Size = new System.Drawing.Size(195, 22);
            this.secondbox.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(57, 300);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 29);
            this.label5.TabIndex = 24;
            this.label5.Text = "2 ingrediente";
            // 
            // firstbox
            // 
            this.firstbox.Location = new System.Drawing.Point(327, 250);
            this.firstbox.Margin = new System.Windows.Forms.Padding(4);
            this.firstbox.Name = "firstbox";
            this.firstbox.Size = new System.Drawing.Size(195, 22);
            this.firstbox.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(321, 217);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 29);
            this.label4.TabIndex = 22;
            this.label4.Text = "1 ingrediente";
            // 
            // savebutton
            // 
            this.savebutton.BackColor = System.Drawing.Color.White;
            this.savebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savebutton.Location = new System.Drawing.Point(355, 409);
            this.savebutton.Margin = new System.Windows.Forms.Padding(4);
            this.savebutton.Name = "savebutton";
            this.savebutton.Size = new System.Drawing.Size(144, 41);
            this.savebutton.TabIndex = 30;
            this.savebutton.Text = "Salva";
            this.savebutton.UseVisualStyleBackColor = false;
            this.savebutton.Click += new System.EventHandler(this.savebutton_Click);
            // 
            // Modifica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(603, 486);
            this.Controls.Add(this.savebutton);
            this.Controls.Add(this.fourthbox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.thirdbox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.secondbox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.firstbox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.pricebox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.searchbutton);
            this.Controls.Add(this.namebox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(621, 533);
            this.MinimumSize = new System.Drawing.Size(621, 533);
            this.Name = "Modifica";
            this.Text = "Ristorante";
            this.Load += new System.EventHandler(this.Modifica_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox namebox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button searchbutton;
        private System.Windows.Forms.TextBox pricebox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox fourthbox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox thirdbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox secondbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox firstbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button savebutton;
    }
}